
var krms_config ={		
	'ApiUrl':"http://myhalaleats.com/mobileapp/api",
	'DialogDefaultTitle':"YOUR_OWN_DIALOG_TITLE",
	'pushNotificationSenderid':"YOUR_ANDROID_PUSH_PROJECT_ID",
	'facebookAppId':"796560520473152"
};